package com.mycompany.embifi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
