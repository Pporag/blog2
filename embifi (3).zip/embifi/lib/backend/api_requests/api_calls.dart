import 'dart:convert';

import '../../flutter_flow/flutter_flow_util.dart';

import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class SendInfoCall {
  static Future<ApiCallResponse> call({
    List<String>? messageList,
    List<int>? sizeList,
  }) {
    final message = _serializeList(messageList);
    final size = _serializeList(sizeList);

    return ApiManager.instance.makeApiCall(
      callName: 'send info',
      apiUrl:
          'https://gm1d0domz8.execute-api.ap-south-1.amazonaws.com/sendform',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer YOUR_TOKEN',
      },
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      cache: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}
