// Export pages
export 'home_page/home_page_widget.dart' show HomePageWidget;
export 'blog/blog_widget.dart' show BlogWidget;
export 'privatepocily/privatepocily_widget.dart' show PrivatepocilyWidget;
export 'blog2/blog2_widget.dart' show Blog2Widget;
